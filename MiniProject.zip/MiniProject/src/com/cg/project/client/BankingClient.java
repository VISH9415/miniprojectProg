package com.cg.project.client;

public class BankingClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
