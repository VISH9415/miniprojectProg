package com.cg.project.bean;

import java.util.Date;



public class AccountBean {
private long accountId;
private String accountType;
private Date openDate;
private double accountBalance;
}
