package com.cg.project.bean;

public class CustomerBean {

	private long accountId;
	private String customerName;
	private String email;
	private String address;
	private String pancard;
}
